﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola mundo, soy Nayra");
            Console.WriteLine("hola, segunda prueba. Introduce una cadena");

            String cad = Console.ReadLine();
            Console.WriteLine("Esto es lo que has escrito: " + cad);
            Console.WriteLine("Y ahora sin espacios delante y detras y en mayusculas: " 
                + cad.Trim().ToUpper());

            int numero = 3;
            double concomas = 3.5;
            Console.WriteLine("el numero es: "+numero);
            Console.WriteLine("Escribe otro numero:");
            numero = Convert.ToInt32(Console.ReadLine());

            if (numero > 10)
            {
                Console.WriteLine("El numero es mayor que 10");
            }else
                Console.WriteLine("El numero es menor que 10");
            //Test clases
            Coche cochecito = new Coche("negro", "renault");
            Console.WriteLine("El color de cochecito es:" + cochecito.GetColor());

            //Test array
            Coche[] arrayCoches = new Coche[4];
            arrayCoches[0] = new Coche("rojo", "porche");
            arrayCoches[1] = new Coche("amarillo", "seat");
            arrayCoches[2] = new Coche("gris", "citroen");
            arrayCoches[3] = cochecito;

            //recorrerlo for normal
            for(int i=0;i < arrayCoches.Length; i++)
            {
                Console.WriteLine(String.Format(
                    "El coche en la posicion {0} tiene color {1} y es de la marca {2} " +
                    "y el color {1} me parece el peor de la marca {2}.",i, arrayCoches[i].GetColor(), arrayCoches[i].GetMarca()));
            }

            //recorrerlo foreach
            foreach(Coche c in arrayCoches)
            {
                Console.WriteLine(String.Format(
                    "El coche tiene color {0} y es de la marca {1} " +
                    "y el color {0} me parece el peor de la marca {1}.", c.GetColor(), c.GetMarca()));
            }





            //Escribir en fichero
            try { 
                StreamWriter sw = new StreamWriter("E:\\copia_segur\\Text_w_csharp.txt",true);
                sw.WriteLine("Prueba escritura Csharp de nuevo");
                sw.Close();
            }
            catch(Exception e) {
                Console.WriteLine(e.Message);
            }

            //leer fichero
            try { 
                StreamReader sr = new StreamReader("E:\\copia_segur\\Text_w_csharp.txt");
                string linea;
                linea = sr.ReadLine();
                while (linea != null)
                {
                    Console.WriteLine(linea);
                    linea = sr.ReadLine();
                }

                sr.Close();

            } catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }   
                
                
                
                
                
                Console.WriteLine("Presiona cualquier tecla para salir");
            Console.ReadLine();

        }
    }
}
