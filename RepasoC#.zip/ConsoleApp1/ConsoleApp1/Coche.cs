﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Coche
    {
        private string Color;
        private string Marca;

        public Coche(string color, string marca)
        {
            this.Color = color;
            this.Marca = marca;

        }

        public string GetColor()
        {
            return Color;
        }

        public string GetMarca()
        {
            return Marca;
        }

        public void SetColor(string color)
        {
            this.Color = color;
        }

        public void SetMarca(string marca)
        {
            this.Marca = marca;
        }
    }
}
