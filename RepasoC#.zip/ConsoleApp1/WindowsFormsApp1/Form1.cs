﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "Blanco")
                textBox1.Text = "Blanco";
            else
                textBox1.Text = "Negro";

        }

        private void testStringFormat_Click(object sender, EventArgs e)
        {
            int Tbase = 9;
            int Taltura = 5;
            float Tarea = (Tbase * Taltura) / 2;
            areaTexto.Text = String.Format("La base del triangulo es {0} y la altura es {1}, el resultado entonces es {2}.",Tbase,Taltura,Tarea);
        }
    }
}
